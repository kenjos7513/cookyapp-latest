<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class Recipe extends Model {

    protected $table = 'recipes';

    protected $fillable = [
        'name',
        'number_of_servings',
        'preparation_time',
        'image_path',
        'ingredients',
        'procedure',
        'user_id'
    ];

    public function user() {
        return $this->belongsTo(User::class, 'user_id');
    }
}