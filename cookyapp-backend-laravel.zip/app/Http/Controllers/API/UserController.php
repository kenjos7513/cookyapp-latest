<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Validator;
use App\Interfaces\UserRepositoryInterface;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    private UserRepositoryInterface $userRepository;
    private $successStatus = 200;


    public function __construct(UserRepositoryInterface $userRepository) {
        $this->userRepository = $userRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        //

        $validator = Validator::make($request->all(), [
            'email' => 'required|email|unique:users',
            'name' => 'required',
            'password' => 'required|min:8',
            're_password' => 'required|same:password',
        ]);

        if ($validator->fails()) {
            return response()->json(['error'=>$validator->errors()], 401);
        }

        //map all form fields
        $input = $request->all();

        
        //create now the user as basic user
        $createdUser = $this->userRepository->create([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' =>  Hash::make($input['password']),
            'role_id' => 2
        ]);

        return response()->json([
            'status' => 'ok',
            'token' => $createdUser->createToken('cookyapp')->plainTextToken,
            'user' => $createdUser
        ], $this->successStatus);


    }

    public function login(Request $request)
    {
        $errorMessage = 'Wrong username or password.';

        $validator = Validator::make($request->all(), [
            'email' => 'required',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error'=> $errorMessage], 401);
        }

        $credentials = $request->all();
        

        if (Auth::attempt($credentials)) {
            $token = $request->user()->createToken('cookyapp');
            $checkUser = $this->userRepository->getUserByEmail($credentials['email']);

            return response()->json([
                'token' => $token->plainTextToken,
                'user' => [
                    'id' => $checkUser->id,
                    'name' => $checkUser->name,
                    'email' => $checkUser->email,
                    'role_id' => $checkUser->role_id
                ]
            ], $this->successStatus);
            
        } else
            return response()->json(['error'=> $errorMessage], 401);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
