<?php

namespace App\Http\Controllers\API;
use Validator;
use Illuminate\Http\Request;
use App\Interfaces\RecipeRepositoryInterface;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\Models\Recipe;

class RecipeController extends Controller
{
    
    private $successStatus = 200;
    private RecipeRepositoryInterface $recipeRepository;


    public function __construct(RecipeRepositoryInterface $recipeRepository)
    {
        $this->recipeRepository = $recipeRepository;
    }

    public function getAllRecipesByOtherUser(Request $request, $user_id)
    {
        $recipes = $this->recipeRepository->getAllRecipesByOtherUser($user_id);



        return response()->json([
            'items' => $recipes
        ],$this->successStatus);


    }
    public function getAllRecipesByUserId(Request $request, $user_id)
    {
        $recipes = $this->recipeRepository->getAllRecipesByUserId($user_id);

        return response()->json([
            'items' => $recipes
        ],$this->successStatus);

    }    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $recipe_id)
    {        

        $checkRecipe = $this->recipeRepository->getRecipeById($recipe_id);

        return response()->json([
            'success' => true,
            'recipe' => $checkRecipe
        ], $this->successStatus);

    }   


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$recipe_id)
    {
        $this->recipeRepository->delete($recipe_id);

        return response()->json([
            'status' => 'ok'
        ], $this->successStatus);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $checkRecipe = $this->recipeRepository->getRecipeById($id);

        if ( isset($checkRecipe->id) ) {

            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'number_of_servings' => 'required',
                'preparation_time' => 'required',
                'image_path' => 'file',
                'ingredients' => 'required',
                'procedure' => 'required',
                'user_id' => 'required'
            ]);
    
            if ($validator->fails()) {
                return response()->json(['error'=>$validator->errors()], 401);
            }
    
            //map all form fields
            $input = $request->all();
            
            $updateFields = [
                'name' => $input['name'],
                'number_of_servings' => $input['number_of_servings'],
                'preparation_time' => $input['preparation_time'],
                'ingredients' => $input['ingredients'],
                'procedure' => $input['procedure']
            ];

            if ( $request->has('image_path') ) {

                //upload now the file
                $final_display_name = '';
                $hash_file = md5($request->file('image_path')->getClientOriginalName() . now());
                $final_display_name = $hash_file . '.' . $request->file('image_path')->guessExtension();
                $final_name = $final_display_name;
                Storage::disk('public')->putFileAs('/recipes', $request->file('image_path'),    $final_name);
                $updateFields['image_path'] = $final_name;
            }

            $checkRecipe->name = $input['name'];
            $checkRecipe->number_of_servings = $input['number_of_servings'];
            $checkRecipe->preparation_time = $input['preparation_time'];
            $checkRecipe->ingredients = $input['ingredients'];
            $checkRecipe->procedure = $input['procedure'];
            
            if ( isset($updateFields['image_path']) ) {
                $checkRecipe->image_path = $updateFields['image_path'];
            }
            $checkRecipe->save();
    
            return response()->json([
                'success' => true,
                'recipe' => $checkRecipe
            ], $this->successStatus);
        }

    }


     /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'number_of_servings' => 'required',
            'preparation_time' => 'required',
            'image_path' => 'required|file',
            'ingredients' => 'required',
            'procedure' => 'required',
            'user_id' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json(['error'=>$validator->errors()], 401);
        }

        //map all form fields
        $input = $request->all();
        

        //upload now the file
        $final_display_name = '';
        $hash_file = md5($request->file('image_path')->getClientOriginalName() . now());
        $final_display_name = $hash_file . '.' . $request->file('image_path')->guessExtension();
        $final_name = $final_display_name;
        Storage::disk('public')->putFileAs('/recipes', $request->file('image_path'), $final_name);


        //create now the recipe
        $createdRecipe = $this->recipeRepository->create([
            'name' => $input['name'],
            'number_of_servings' => $input['number_of_servings'],
            'preparation_time' => $input['preparation_time'],
            'image_path' => $final_name,
            'ingredients' => $input['ingredients'],
            'procedure' => $input['procedure'],
            'user_id' => $input['user_id']
        ]);

        return response()->json([
            'success' => true,
            'recipe' => $createdRecipe
        ], $this->successStatus);

    }



}
