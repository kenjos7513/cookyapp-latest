<?php

namespace App\Interfaces;

interface UserRepositoryInterface 
{
    public function getAllUsers();
    public function getUserById($userId);
    public function getUserByEmail($email);
    public function delete($userId);
    public function create(array $userDetails);
    public function update($userId, array $newDetails);
}