<?php

namespace App\Interfaces;

interface RecipeRepositoryInterface 
{
    public function getAllRecipes();
    public function getRecipeById($recipeId);
    public function delete($recipeId);
    public function create(array $recipeDetails);
    public function update($recipeId, array $newDetails);
    public function getAllRecipesByUserId($userId);
    public function getAllRecipesByOtherUser($userId);

}