<?php

namespace App\Repositories;

use App\Interfaces\RecipeRepositoryInterface;
use App\Models\Recipe;


class RecipeRepository implements RecipeRepositoryInterface 
{
    public function getAllRecipes() 
    {
        return Recipe::all();
    }
    

    public function getAllRecipesByOtherUser($userId)
    {
        return Recipe::with('user')->where('user_id','<>',$userId)->orderBy('id','desc')->get();
    }
    public function getAllRecipesByUserId($userId)
    {
        return Recipe::with('user')->where('user_id', $userId)->orderBy('id','desc')->get();
    }

    public function getRecipeById($recipeId) 
    {
        return Recipe::with('user')->where('id',$recipeId)->first();
    }

    public function delete($recipeId) 
    {
        Recipe::destroy($recipeId);
    }

    public function create(array $recipeDetails) 
    {
        return Recipe::create($recipeDetails);
    }

    public function update($recipeId, array $newDetails) 
    {
        return Recipe::whereId($recipeId)->update($newDetails);
    }
}