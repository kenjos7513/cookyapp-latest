<?php

namespace App\Repositories;

use App\Interfaces\UserRepositoryInterface;
use App\Models\User;

class UserRepository implements UserRepositoryInterface 
{
    public function getAllUsers() 
    {
        return User::all();
    }
    public function getUserByEmail($email)
    {
        return User::where('email', $email)->first();
    }

    public function getUserById($userId) 
    {
        return User::findOrFail($userId);
    }

    public function delete($userId) 
    {
        User::destroy($userId);
    }

    public function create(array $userDetails) 
    {
        return User::create($userDetails);
    }

    public function update($userId, array $newDetails) 
    {
        return User::whereId($userId)->update($newDetails);
    }
}