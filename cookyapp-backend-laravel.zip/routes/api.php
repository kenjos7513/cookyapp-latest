<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


//register user
Route::post('register', 'App\Http\Controllers\API\UserController@create');


//login user
Route::post('login', 'App\Http\Controllers\API\UserController@login');


Route::group(['middleware' => 'auth:sanctum'], function () {


    //fetch recipes
    Route::get('get-all-recipes-by-user-id/{user_id}','App\Http\Controllers\API\RecipeController@getAllRecipesByUserId');

    Route::get('get-all-recipes-by-other-user/{user_id}',
    'App\Http\Controllers\API\RecipeController@getAllRecipesByOtherUser');


    //get recipe by id
    Route::get('recipe/{recipe_id}','App\Http\Controllers\API\RecipeController@show');

    //create recipe
    Route::post('recipe/create','App\Http\Controllers\API\RecipeController@create');

    //update recipe
    Route::post('recipe/edit/{recipe_id}','App\Http\Controllers\API\RecipeController@update');

    //delete recipe
    Route::delete('recipe/{recipe_id}', 'App\Http\Controllers\API\RecipeController@destroy');

});


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});