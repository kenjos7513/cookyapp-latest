<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        //insert now the roles
        \DB::table('users')->insert([
            [
                'name' => 'Admin',
                'email' => 'admin@gmail.com',
                'password' =>  Hash::make('testpassword12345'),
                'role_id' => 1
            ],
            [
                'name' => 'Basic User',
                'email' => 'basicUser@gmail.com',
                'password' =>  Hash::make('testpassword12345'),
                'role_id' => 2
            ],

        ]);
    }
}