<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        //insert now the roles
        \DB::table('roles')->insert([
            [
                'name'=>'Admin',
            ],
            [
                'name'=>'Basic User',
            ],

        ]);
    }
}
